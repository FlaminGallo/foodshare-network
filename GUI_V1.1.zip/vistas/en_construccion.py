# vistas/en_construccion.py
import tkinter as tk
import tkinter.ttk as ttk
import estilos

class EnConstruccion(ttk.Frame):
    def __init__(self, parent, app):
        super().__init__(parent, style="Panel.TFrame")
        self.app = app
        
        # Contenido centrado
        lbl_titulo = ttk.Label(self, text="⚙️ Pantalla en Construcción", style="Titulo.TLabel")
        lbl_titulo.pack(expand=True)
        
        lbl_sub = ttk.Label(self, text="Esta sección estará disponible en las próximas etapas.", style="TLabel")
        lbl_sub.pack(pady=10)

    def actualizar(self):
        """Método requerido por main.py al mostrar la pantalla."""
        pass