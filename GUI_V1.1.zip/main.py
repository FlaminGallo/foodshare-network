# main.py
import tkinter as tk
import tkinter.ttk as ttk
import estilos
import datos_demo
from vistas import Login, EnConstruccion

class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("FoodShare Network")
        self.geometry("900x600")
        self.resizable(False, False)
        
        self.usuario_actual = None
        self.botones_menu = {} # Guardar referencias a los botones del menú

        estilos.configurar_estilos()
        self.configure(bg=estilos.BG_VENTANA)

        self.columnconfigure(1, weight=1) 
        self.rowconfigure(0, weight=1)

        # 1. Menú lateral (oculto por defecto)
        self.sidebar = ttk.Frame(self, style="Sidebar.TFrame", width=200)
        self.sidebar.pack_propagate(False) # Forzar el ancho fijo de 200px (usando pack internamente)
        
        # 2. Área de contenido principal
        self.content_area = ttk.Frame(self, style="TFrame")
        self.content_area.grid(row=0, column=1, sticky="nsew")
        self.content_area.rowconfigure(0, weight=1)
        self.content_area.columnconfigure(0, weight=1)

        self.frames = {}
        for F in (Login, EnConstruccion):
            nombre_vista = F.__name__
            frame = F(parent=self.content_area, app=self)
            frame.grid(row=0, column=0, sticky="nsew")
            self.frames[nombre_vista] = frame

        self.mostrar_pantalla("Login")

    def mostrar_pantalla(self, nombre_vista):
        """Trae al frente la vista solicitada y actualiza sus datos."""
        # Resaltar la opción en el menú si existe
        for vista, btn in self.botones_menu.items():
            if vista == nombre_vista:
                btn.config(style="MenuLateralActivo.TButton")
            else:
                btn.config(style="MenuLateral.TButton")

        if nombre_vista not in self.frames:
            nombre_vista = "EnConstruccion"
            
        frame = self.frames[nombre_vista]
        frame.tkraise() 
        
        if hasattr(frame, "actualizar") and callable(getattr(frame, "actualizar")):
            frame.actualizar()

    def iniciar_sesion(self, email):
        self.usuario_actual = datos_demo.USUARIOS[email]
        self._construir_menu()
        self.sidebar.grid(row=0, column=0, sticky="ns") 
        
        rol = self.usuario_actual["rol"]
        if rol == "restaurante":
            self.mostrar_pantalla("PanelRestaurante") 
        elif rol == "fundacion":
            self.mostrar_pantalla("ExplorarDonaciones")
        elif rol == "admin":
            self.mostrar_pantalla("PanelAdmin")

    def cerrar_sesion(self):
        self.usuario_actual = None
        self.botones_menu.clear()
        self.sidebar.grid_forget() 
        self.mostrar_pantalla("Login")

    def _construir_menu(self):
        for widget in self.sidebar.winfo_children():
            widget.destroy()

        # Título del menú / Perfil
        lbl_perfil = ttk.Label(self.sidebar, text=f"Usuario:\n{self.usuario_actual['nombre_entidad']}", 
                               style="Subtitulo.TLabel", background=estilos.BG_SIDEBAR)
        lbl_perfil.pack(pady=(20, 30), padx=10, anchor="w")

        opciones = []
        rol = self.usuario_actual["rol"]
        
        if rol == "restaurante":
            opciones = [("Panel", "PanelRestaurante"), ("Publicar donación", "PublicarDonacion"), 
                        ("Mis donaciones", "MisDonaciones"), ("Alertas", "Alertas")]
        elif rol == "fundacion":
            opciones = [("Explorar donaciones", "ExplorarDonaciones"), ("Mis reservas", "MisReservas"), 
                        ("Alertas", "Alertas")]
        elif rol == "admin":
            opciones = [("Panel", "PanelAdmin"), ("Donaciones", "AdminDonaciones"), 
                        ("Usuarios", "AdminUsuarios"), ("Alertas", "Alertas")]

        # Crear botones de navegación y guardarlos
        for texto, vista in opciones:
            btn = ttk.Button(self.sidebar, text=texto, style="MenuLateral.TButton", 
                             command=lambda v=vista: self.mostrar_pantalla(v))
            btn.pack(fill="x", padx=10, pady=2)
            self.botones_menu[vista] = btn

        btn_salir = ttk.Button(self.sidebar, text="Cerrar sesión", style="Secundario.TButton", 
                               command=self.cerrar_sesion)
        btn_salir.pack(side="bottom", fill="x", padx=10, pady=20)

if __name__ == "__main__":
    app = App()
    app.mainloop()