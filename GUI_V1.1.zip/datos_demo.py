# datos_demo.py
import datetime

# --- FUNCIONES AUXILIARES ---
def formatear_fecha(fecha):
    """
    Recibe un objeto datetime.date (o un string en formato AAAA-MM-DD) 
    y devuelve una cadena en formato dd/mm/aaaa para la interfaz.
    """
    if isinstance(fecha, str):
        fecha = datetime.datetime.strptime(fecha, "%Y-%m-%d").date()
    return fecha.strftime("%d/%m/%Y")


# Fechas calculadas dinámicamente basadas en el día de hoy
hoy = datetime.date.today()

# --- USUARIOS DEL SISTEMA ---
# NOTA DE SEGURIDAD: Las contraseñas incluidas en este diccionario se guardan 
# en texto plano EXCLUSIVAMENTE con fines de demostración académica. 
# En el sistema real de producción, las contraseñas nunca deben guardarse así; 
# deberán almacenarse cifradas mediante funciones hash (ej. bcrypt o Argon2).
USUARIOS = {
    "contacto@elbuensabor.mx": {
        "clave": "claveRestaurante2024",
        "rol": "restaurante",
        "nombre_entidad": "El Buen Sabor",
        "responsable": "Juan Pérez"
    },
    "recepcion@bancoesperanza.org": {
        "clave": "claveFundacion2024",
        "rol": "fundacion",
        "nombre_entidad": "Banco Esperanza",
        "responsable": "María Gómez"
    },
    "admin@foodshare.org": {
        "clave": "rootAdminODS123",
        "rol": "admin",
        "nombre_entidad": "Administración Central",
        "responsable": "Lic. Ana Ruiz"
    }
}

# --- CATÁLOGO DE DONACIONES ---
# Lista de diccionarios que simula la tabla de donaciones.
# Las claves han sido renombradas para coincidir con el diagrama UML.
DONACIONES = [
    {
        "id_donacion": "DON028",
        "descripcion": "Frutas de temporada (manzana, plátano)",
        "peso_kg": 25.0,
        "fecha_vencimiento": hoy + datetime.timedelta(days=3), # Futuro
        "estado": "Reservada",
        "restaurante": "Frutería Central",
        "reservado_por": "Banco Esperanza"
    },
    {
        "id_donacion": "DON027",
        "descripcion": "Guisado de lentejas con verduras",
        "peso_kg": 20.0,
        "fecha_vencimiento": hoy + datetime.timedelta(days=4), # Futuro
        "estado": "Disponible",
        "restaurante": "Comedor La Esquina",
        "reservado_por": None
    },
    {
        "id_donacion": "DON026",
        "descripcion": "Pan integral horneado",
        "peso_kg": 12.0,
        "fecha_vencimiento": hoy + datetime.timedelta(days=2), # Futuro cercano
        "estado": "Disponible",
        "restaurante": "Panadería San José",
        "reservado_por": None
    },
    {
        "id_donacion": "DON025",
        "descripcion": "Arroz con verduras cocido",
        "peso_kg": 15.0,
        "fecha_vencimiento": hoy + datetime.timedelta(days=5), # Futuro
        "estado": "Disponible",
        "restaurante": "El Buen Sabor",
        "reservado_por": None
    },
    {
        "id_donacion": "DON024",
        "descripcion": "Verduras variadas (calabaza, zanahoria)",
        "peso_kg": 32.0,
        "fecha_vencimiento": hoy + datetime.timedelta(days=1), # Futuro próximo
        "estado": "Disponible",
        "restaurante": "El Buen Sabor",
        "reservado_por": None
    },
    {
        "id_donacion": "DON023",
        "descripcion": "Arroz cocido al vapor",
        "peso_kg": 18.5,
        "fecha_vencimiento": hoy + datetime.timedelta(days=2), # Futuro
        "estado": "Reservada",
        "restaurante": "El Buen Sabor",
        "reservado_por": "Banco Esperanza"
    },
    {
        "id_donacion": "DON022",
        "descripcion": "Pan de caja integral",
        "peso_kg": 15.0,
        "fecha_vencimiento": hoy - datetime.timedelta(days=2), # Pasado reciente
        "estado": "Entregada",
        "restaurante": "El Buen Sabor",
        "reservado_por": "Banco Esperanza"
    },
    {
        "id_donacion": "DON021",
        "descripcion": "Pollo guisado en salsa",
        "peso_kg": 20.0,
        "fecha_vencimiento": hoy - datetime.timedelta(days=5), # Pasado
        "estado": "Vencida",
        "restaurante": "El Buen Sabor",
        "reservado_por": None
    }
]