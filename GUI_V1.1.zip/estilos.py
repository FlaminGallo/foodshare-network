# estilos.py
import tkinter.ttk as ttk

# --- PALETA DE COLORES (Constantes) ---
BG_VENTANA = "#F8FAFC"      
BG_PANEL = "#FFFFFF"        
BG_SIDEBAR = "#EDF4FF"      

BORDE = "#CBD5E1"           

PRIMARIO = "#1F6F43"        
PRIMARIO_HOVER = "#165634"  

TEXTO_PRINCIPAL = "#141C25" 
TEXTO_SECUNDARIO = "#3F4941"

ESTADO_DISPONIBLE = "#1F6F43" 
ESTADO_RESERVADA = "#1D4ED8"  
ESTADO_ENTREGADA = "#64748B"  
ESTADO_VENCIDA = "#B91C1C"    

FUENTE_BASE = ("Segoe UI", 10)
FUENTE_TITULO = ("Segoe UI", 14, "bold")
FUENTE_SUBTITULO = ("Segoe UI", 11, "bold")
FUENTE_MONO = ("Consolas", 10)

def configurar_estilos():
    style = ttk.Style()
    style.theme_use('clam')

    # Contenedores
    style.configure("TFrame", background=BG_VENTANA)
    style.configure("Panel.TFrame", background=BG_PANEL)
    style.configure("Sidebar.TFrame", background=BG_SIDEBAR)

    # Etiquetas (Fondo general)
    style.configure("TLabel", background=BG_VENTANA, foreground=TEXTO_PRINCIPAL, font=FUENTE_BASE)
    style.configure("Titulo.TLabel", font=FUENTE_TITULO, foreground=PRIMARIO, background=BG_VENTANA)
    style.configure("Subtitulo.TLabel", font=FUENTE_SUBTITULO, foreground=TEXTO_PRINCIPAL, background=BG_VENTANA)
    
    # Etiquetas (Fondo blanco de paneles)
    style.configure("Panel.TLabel", background=BG_PANEL, foreground=TEXTO_PRINCIPAL, font=FUENTE_BASE)
    style.configure("PanelTitulo.TLabel", font=FUENTE_TITULO, foreground=PRIMARIO, background=BG_PANEL)
    style.configure("PanelSubtitulo.TLabel", font=FUENTE_SUBTITULO, foreground=TEXTO_PRINCIPAL, background=BG_PANEL)

    # Botones principales (Sin efecto 3D)
    style.configure("Primario.TButton", 
                    background=PRIMARIO, 
                    foreground="#FFFFFF", 
                    font=("Segoe UI", 10, "bold"),
                    borderwidth=1,
                    bordercolor=PRIMARIO,
                    lightcolor=PRIMARIO,
                    darkcolor=PRIMARIO,
                    padding=5)
    style.map("Primario.TButton", background=[("active", PRIMARIO_HOVER)])

    # Botones secundarios (Sin efecto 3D)
    style.configure("Secundario.TButton", 
                    background=BG_PANEL, 
                    foreground=TEXTO_PRINCIPAL, 
                    font=("Segoe UI", 10),
                    borderwidth=1, 
                    bordercolor=BORDE,
                    lightcolor=BORDE,
                    darkcolor=BORDE,
                    padding=5)
    style.map("Secundario.TButton", background=[("active", "#E2E8F0")])

    # Botones del Menú Lateral (Planos)
    style.configure("MenuLateral.TButton", 
                    background=BG_SIDEBAR, 
                    foreground=TEXTO_PRINCIPAL, 
                    font=FUENTE_BASE, 
                    borderwidth=0, 
                    anchor="w", 
                    padding=10)
    style.map("MenuLateral.TButton", background=[("active", "#E2E8F0")])

    # Botón de Menú Lateral Activo
    style.configure("MenuLateralActivo.TButton", 
                    background=PRIMARIO, 
                    foreground="#FFFFFF", 
                    font=("Segoe UI", 10, "bold"), 
                    borderwidth=0, 
                    anchor="w", 
                    padding=10)

    # Tablas (Treeview)
    style.configure("Treeview", 
                    background=BG_PANEL, 
                    foreground=TEXTO_PRINCIPAL, 
                    fieldbackground=BG_PANEL, 
                    rowheight=30, 
                    font=FUENTE_BASE,
                    borderwidth=0)
    style.map("Treeview", 
              background=[("selected", "#D1FAE5")], 
              foreground=[("selected", TEXTO_PRINCIPAL)])

    style.configure("Treeview.Heading", 
                    background="#F1F5F9", 
                    foreground=TEXTO_SECUNDARIO, 
                    font=("Segoe UI", 9, "bold"),
                    borderwidth=1, 
                    relief="flat")