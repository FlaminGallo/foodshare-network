"""estilos.py — Paleta de colores, fuentes y estilos ttk de FoodShare Network.

CONTRATO (no modificable):
    Constantes de color (BG_*, BORDE, PRIMARIO, TEXTO_*, ESTADO_*) y fuentes
    (FUENTE_*) + función configurar_estilos().
"""

import tkinter as tk
from tkinter import ttk

# ── Paleta de colores (especificación funcional) ─────────────────
BG_VENTANA = "#F8FAFC"
BG_PANEL = "#FFFFFF"
BG_SIDEBAR = "#EDF4FF"
BORDE = "#CBD5E1"
PRIMARIO = "#1F6F43"
PRIMARIO_HOVER = "#165634"
TEXTO_PRINCIPAL = "#141C25"
TEXTO_SECUNDARIO = "#3F4941"
ESTADO_DISPONIBLE = "#1F6F43"
ESTADO_RESERVADA = "#1D4ED8"
ESTADO_ENTREGADA = "#64748B"
ESTADO_VENCIDA = "#B91C1C"

# ── Colores derivados (constantes internas, NO forman parte del contrato) ──
TEXTO_BLANCO = "#FFFFFF"
GRIS_HOVER = "#E2E8F0"        # hover de Secundario.TButton y botones demo
AZUL_HOVER_MENU = "#DCE9FF"   # hover de MenuLateral.TButton

# ── Fuentes (Segoe UI 10 / 14 bold / 11 bold y Consolas 10) ─────
FUENTE_BASE = ("Segoe UI", 10)
FUENTE_TITULO = ("Segoe UI", 14, "bold")
FUENTE_SUBTITULO = ("Segoe UI", 11, "bold")
FUENTE_MONO = ("Consolas", 10)

# ── Fuentes derivadas (constantes internas, NO forman parte del contrato) ──
FUENTE_BASE_BOLD = (FUENTE_BASE[0], FUENTE_BASE[1], "bold")
FUENTE_PESTANA = ("Segoe UI", 9)
FUENTE_PESTANA_ACTIVA = ("Segoe UI", 9, "bold")


def configurar_estilos():
    """Aplica el tema 'clam' y define todos los estilos ttk del contrato."""
    estilo = ttk.Style()
    estilo.theme_use("clam")

    # ── Frames ──
    estilo.configure("TFrame", background=BG_VENTANA)
    estilo.configure("Panel.TFrame", background=BG_PANEL)
    estilo.configure("Sidebar.TFrame", background=BG_SIDEBAR)

    # ── Etiquetas ──
    estilo.configure(
        "TLabel", background=BG_VENTANA, foreground=TEXTO_PRINCIPAL, font=FUENTE_BASE
    )
    # Titulo/Subtitulo se usan dentro de paneles (fondo blanco)
    estilo.configure(
        "Titulo.TLabel", background=BG_PANEL, foreground=TEXTO_PRINCIPAL, font=FUENTE_TITULO
    )
    estilo.configure(
        "Subtitulo.TLabel",
        background=BG_PANEL,
        foreground=TEXTO_SECUNDARIO,
        font=FUENTE_SUBTITULO,
    )
    estilo.configure(
        "Panel.TLabel", background=BG_PANEL, foreground=TEXTO_PRINCIPAL, font=FUENTE_BASE
    )

    # ── Botón primario: verde, texto blanco, bold, hover oscuro, plano ──
    estilo.configure(
        "Primario.TButton",
        background=PRIMARIO,
        foreground=TEXTO_BLANCO,
        font=FUENTE_BASE_BOLD,
        borderwidth=0,
        focusthickness=0,
        padding=(10, 8),
        relief="flat",
    )
    estilo.map(
        "Primario.TButton",
        background=[("pressed", PRIMARIO_HOVER), ("active", PRIMARIO_HOVER)],
        foreground=[("disabled", TEXTO_BLANCO)],
    )

    # ── Botón secundario: blanco con borde BORDE, hover gris claro ──
    estilo.configure(
        "Secundario.TButton",
        background=TEXTO_BLANCO,
        foreground=TEXTO_PRINCIPAL,
        font=FUENTE_BASE,
        borderwidth=1,
        bordercolor=BORDE,
        focusthickness=0,
        padding=(10, 8),
        relief="solid",
    )
    estilo.map(
        "Secundario.TButton",
        background=[("pressed", GRIS_HOVER), ("active", GRIS_HOVER)],
    )

    # ── Botones del menú lateral ──
    estilo.configure(
        "MenuLateral.TButton",
        background=BG_SIDEBAR,
        foreground=TEXTO_PRINCIPAL,
        font=FUENTE_BASE,
        anchor="w",
        padding=10,
        borderwidth=0,
        relief="flat",
    )
    estilo.map(
        "MenuLateral.TButton",
        background=[("active", AZUL_HOVER_MENU)],
    )
    estilo.configure(
        "MenuLateralActivo.TButton",
        background=PRIMARIO,
        foreground=TEXTO_BLANCO,
        font=FUENTE_BASE_BOLD,
        anchor="w",
        padding=10,
        borderwidth=0,
        relief="flat",
    )
    estilo.map(
        "MenuLateralActivo.TButton",
        background=[("active", PRIMARIO_HOVER), ("pressed", PRIMARIO_HOVER)],
    )

    # ── Tablas (para vistas de fases futuras) ──
    estilo.configure(
        "Treeview",
        rowheight=30,
        fieldbackground=BG_PANEL,
        background=BG_PANEL,
        foreground=TEXTO_PRINCIPAL,
        font=FUENTE_BASE,
        bordercolor=BORDE,
    )
    estilo.map("Treeview", background=[("selected", "#D1FAE5")])
    estilo.configure(
        "Treeview.Heading",
        background="#F1F5F9",
        foreground=TEXTO_PRINCIPAL,
        font=(FUENTE_BASE[0], 9, "bold"),
        relief="flat",
    )
