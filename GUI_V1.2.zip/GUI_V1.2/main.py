"""main.py — Punto de entrada de FoodShare Network (demo ODS 2).

Clase App(tk.Tk): orquesta estilos, sidebar y apilado de vistas.
Expone a las vistas: iniciar_sesion(email), mostrar_pantalla(nombre),
cerrar_sesion() y usuario_actual (CONTRATO, no modificable).
"""

import tkinter as tk
from tkinter import ttk

import estilos
from datos_demo import USUARIOS
from vistas import EnConstruccion, Login

# Menú lateral por rol: (texto del botón, nombre de pantalla destino)
MENUS_POR_ROL = {
    "restaurante": [
        ("Panel", "PanelRestaurante"),
        ("Publicar donación", "PublicarDonacion"),
        ("Mis donaciones", "MisDonaciones"),
        ("Alertas", "Alertas"),
    ],
    "fundacion": [
        ("Explorar donaciones", "ExplorarDonaciones"),
        ("Mis reservas", "MisReservas"),
        ("Alertas", "Alertas"),
    ],
    "admin": [
        ("Panel", "PanelAdmin"),
        ("Donaciones", "Donaciones"),
        ("Usuarios", "Usuarios"),
        ("Alertas", "Alertas"),
    ],
}

# Pantalla a la que navega tras iniciar sesión, según el rol
PANTALLA_INICIO = {
    "restaurante": "PanelRestaurante",
    "fundacion": "ExplorarDonaciones",
    "admin": "PanelAdmin",
}


class App(tk.Tk):
    """Ventana principal: sidebar + área de contenido con vistas apiladas."""

    def __init__(self):
        super().__init__()
        self.title("FoodShare Network")
        self.geometry("900x600")
        self.resizable(False, False)

        self.usuario_actual = None
        self.botones_menu = {}

        estilos.configurar_estilos()
        self.configure(bg=estilos.BG_VENTANA)

        # Grid: col 0 = sidebar, col 1 = content_area (expandible)
        self.grid_columnconfigure(0, weight=0)
        self.grid_columnconfigure(1, weight=1)
        self.grid_rowconfigure(0, weight=1)

        # Sidebar: ancho fijo 200, oculto al inicio
        self.sidebar = ttk.Frame(self, style="Sidebar.TFrame", width=200)
        self.sidebar.pack_propagate(False)

        # Área de contenido apilado de vistas
        self.content_area = tk.Frame(self, bg=estilos.BG_VENTANA)
        self.content_area.grid(row=0, column=1, sticky="nsew")
        self.content_area.grid_rowconfigure(0, weight=1)
        self.content_area.grid_columnconfigure(0, weight=1)

        self.frames = {}
        for clase in (Login, EnConstruccion):
            nombre = clase.__name__
            self.frames[nombre] = clase(self.content_area, self)
            self.frames[nombre].grid(row=0, column=0, sticky="nsew")

        self.mostrar_pantalla("Login")

    # ── Navegación ─────────────────────────────────────────────
    def mostrar_pantalla(self, nombre):
        """Muestra la vista indicada; fallback a EnConstruccion si no existe.

        Resalta el botón activo del menú lateral, eleva la vista con
        tkraise() y la refresca llamando a actualizar() si lo define.
        """
        nombre_solicitado = nombre
        if nombre not in self.frames:
            nombre = "EnConstruccion"

        for pantalla, boton in self.botones_menu.items():
            boton.configure(style="MenuLateral.TButton")
        if nombre_solicitado in self.botones_menu:
            self.botones_menu[nombre_solicitado].configure(
                style="MenuLateralActivo.TButton"
            )

        self.frames[nombre].tkraise()
        if hasattr(self.frames[nombre], "actualizar"):
            self.frames[nombre].actualizar()

    # ── Sesión ───────────────────────────────────────────────────
    def iniciar_sesion(self, email):
        """Guarda el usuario, construye el menú por rol y muestra el sidebar."""
        usuario = USUARIOS[email]
        self.usuario_actual = {"email": email, **usuario}
        self._construir_menu()
        self.sidebar.grid(row=0, column=0, sticky="ns")
        self.mostrar_pantalla(PANTALLA_INICIO[self.usuario_actual["rol"]])

    def _vaciar_sidebar(self):
        """Destruye los widgets del sidebar y resetea el registro de botones."""
        for hijo in self.sidebar.winfo_children():
            hijo.destroy()
        self.botones_menu = {}

    def _construir_menu(self):
        """Crea los botones del menú lateral según el rol del usuario actual."""
        self._vaciar_sidebar()

        rol = self.usuario_actual["rol"]
        for texto, pantalla in MENUS_POR_ROL[rol]:
            boton = ttk.Button(
                self.sidebar,
                text=texto,
                style="MenuLateral.TButton",
                command=lambda p=pantalla: self.mostrar_pantalla(p),
            )
            boton.pack(fill="x", padx=10, pady=(10, 2))
            self.botones_menu[pantalla] = boton

        ttk.Button(
            self.sidebar,
            text="Cerrar sesión",
            style="Secundario.TButton",
            command=self.cerrar_sesion,
        ).pack(side="bottom", fill="x", padx=10, pady=10)

    def cerrar_sesion(self):
        """Limpia el estado, oculta el sidebar y vuelve a la pantalla Login."""
        self.usuario_actual = None
        self._vaciar_sidebar()
        self.sidebar.grid_forget()
        self.mostrar_pantalla("Login")


if __name__ == "__main__":
    App().mainloop()
