"""vistas/login.py — Pantalla de inicio de sesión de FoodShare Network.

Tres pestañas de rol, autocompletado con cuentas demo y validación contra
datos_demo.USUARIOS. Al validar, delega en app.iniciar_sesion(email).
"""

import tkinter as tk
from tkinter import ttk

from datos_demo import USUARIOS
from estilos import (
    BG_PANEL,
    BORDE,
    ESTADO_VENCIDA,
    FUENTE_PESTANA,
    FUENTE_PESTANA_ACTIVA,
    GRIS_HOVER,
    PRIMARIO,
    TEXTO_BLANCO,
    TEXTO_PRINCIPAL,
)

# Textos exactos de la especificación funcional
TEXTO_TITULO = "Control de Acceso"
TEXTO_SUBTITULO = "Plataforma de redistribución | ODS 2 Hambre Cero"
TEXTO_ERROR = "⚠️ Credenciales incorrectas o rol no coincidente."

# Pestañas de rol: (texto visible, rol interno en USUARIOS)
ROLES_PESTANAS = [
    ("Restaurante", "restaurante"),
    ("Fundación", "fundacion"),
    ("Administrador", "admin"),
]

# Cuentas demo: (texto del botón, rol a buscar en USUARIOS)
CUENTAS_DEMO = [
    ("El Buen Sabor", "restaurante"),
    ("Banco Esperanza", "fundacion"),
    ("Administración Central", "admin"),
]


class Login(ttk.Frame):
    """Vista de acceso: valida email, clave y rol contra datos_demo.USUARIOS."""

    def __init__(self, parent, app):
        super().__init__(parent)
        self.app = app

        self.rol_seleccionado = "restaurante"
        self.var_correo = tk.StringVar()
        self.var_clave = tk.StringVar()
        self.var_error = tk.StringVar()
        # La especificación solo pide el Checkbutton; se captura el estado
        # sin persistencia (fuera de alcance de la demo).
        self.var_recordar = tk.BooleanVar(value=False)

        self.botones_rol = {}
        self._construir()

    # ── Construcción de la interfaz ──────────────────────────────
    def _construir(self):
        """Arma el cuadro de acceso: título, pestañas, campos y cuentas demo."""
        # Cuadro centrado
        caja = ttk.Frame(self, style="Panel.TFrame", padding=30)
        caja.place(relx=0.5, rely=0.5, anchor="center")

        ttk.Label(caja, text=TEXTO_TITULO, style="Titulo.TLabel").pack(pady=(0, 4))
        ttk.Label(caja, text=TEXTO_SUBTITULO, style="Subtitulo.TLabel").pack(pady=(0, 16))

        # Pestañas de rol (tk.Button planos, colores manuales)
        fila_roles = tk.Frame(caja, bg=BG_PANEL)
        fila_roles.pack(pady=(0, 16))
        for texto, rol in ROLES_PESTANAS:
            boton = tk.Button(
                fila_roles,
                text=texto,
                relief="flat",
                bd=0,
                padx=14,
                pady=6,
                cursor="hand2",
                command=lambda r=rol: self._seleccionar_rol(r),
            )
            boton.pack(side="left", padx=3)
            self.botones_rol[rol] = boton
        self._pintar_pestanas()

        # Campo correo
        ttk.Label(caja, text="Correo", style="Panel.TLabel").pack(anchor="w")
        ttk.Entry(caja, textvariable=self.var_correo, width=40).pack(pady=(2, 10))

        # Campo contraseña con botón 👁 para alternar visibilidad
        ttk.Label(caja, text="Contraseña", style="Panel.TLabel").pack(anchor="w")
        fila_clave = tk.Frame(caja, bg=BG_PANEL)
        fila_clave.pack(pady=(2, 10), fill="x")
        self.entry_clave = ttk.Entry(
            fila_clave, textvariable=self.var_clave, show="*", width=40
        )
        self.entry_clave.pack(side="left")
        tk.Button(
            fila_clave,
            text="👁",
            relief="flat",
            bd=0,
            bg=BG_PANEL,
            activebackground=BG_PANEL,
            command=self._alternar_visibilidad,
        ).pack(side="left", padx=(6, 0))

        # Recordar sesión
        tk.Checkbutton(
            caja,
            text="Recordar sesión en este equipo",
            variable=self.var_recordar,
            bg=BG_PANEL,
            fg=TEXTO_PRINCIPAL,
            activebackground=BG_PANEL,
            activeforeground=TEXTO_PRINCIPAL,
            selectcolor=BG_PANEL,
        ).pack(anchor="w", pady=(0, 6))

        # Etiqueta de error (roja)
        tk.Label(
            caja, textvariable=self.var_error, bg=BG_PANEL, fg=ESTADO_VENCIDA
        ).pack(pady=(0, 6))

        # Botón de ingreso
        ttk.Button(
            caja,
            text="INGRESAR AL SISTEMA",
            style="Primario.TButton",
            command=self.validar_login,
        ).pack(fill="x", pady=(0, 16))

        # Cuentas demo
        ttk.Label(caja, text="Cuentas demo:", style="Panel.TLabel").pack(anchor="w")
        fila_demo = tk.Frame(caja, bg=BG_PANEL)
        fila_demo.pack(pady=(4, 0))
        for texto, rol in CUENTAS_DEMO:
            tk.Button(
                fila_demo,
                text=texto,
                relief="flat",
                bd=0,
                padx=8,
                pady=4,
                bg=BORDE,
                fg=TEXTO_PRINCIPAL,
                activebackground=GRIS_HOVER,
                cursor="hand2",
                command=lambda r=rol: self._autocompletar(r),
            ).pack(side="left", padx=3)

    # ── Comportamiento ─────────────────────────────────────────
    def _seleccionar_rol(self, rol):
        """Marca la pestaña activa y repinta las tres pestañas."""
        self.rol_seleccionado = rol
        self._pintar_pestanas()

    def _pintar_pestanas(self):
        """Pinta la pestaña activa (verde/blanco) y las inactivas (gris)."""
        for rol, boton in self.botones_rol.items():
            if rol == self.rol_seleccionado:
                boton.configure(
                    bg=PRIMARIO, fg=TEXTO_BLANCO, font=FUENTE_PESTANA_ACTIVA
                )
            else:
                boton.configure(bg=BORDE, fg=TEXTO_PRINCIPAL, font=FUENTE_PESTANA)

    def _alternar_visibilidad(self):
        """Alterna la contraseña entre oculta (*) y visible."""
        nuevo_show = "" if self.entry_clave.cget("show") == "*" else "*"
        self.entry_clave.configure(show=nuevo_show)

    def _autocompletar(self, rol):
        """Busca el primer usuario con el rol dado y rellena email/clave."""
        for email, usuario in USUARIOS.items():
            if usuario["rol"] == rol:
                self.var_correo.set(email)
                self.var_clave.set(usuario["clave"])
                self.var_error.set("")
                return

    def validar_login(self):
        """Valida email + clave + rol; en éxito delega en app.iniciar_sesion()."""
        email = self.var_correo.get().strip()
        clave = self.var_clave.get()
        usuario = USUARIOS.get(email)
        if (
            usuario
            and usuario["clave"] == clave
            and usuario["rol"] == self.rol_seleccionado
        ):
            self.var_error.set("")
            self.var_clave.set("")
            self.app.iniciar_sesion(email)
        else:
            self.var_error.set(TEXTO_ERROR)

    def actualizar(self):
        """Limpia el formulario y restablece el rol activo a 'restaurante'."""
        self.var_correo.set("")
        self.var_clave.set("")
        self.var_error.set("")
        self.var_recordar.set(False)
        self.rol_seleccionado = "restaurante"
        self._pintar_pestanas()
