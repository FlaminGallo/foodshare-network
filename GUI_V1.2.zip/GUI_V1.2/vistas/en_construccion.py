"""vistas/en_construccion.py — Vista de respaldo para pantallas no implementadas.

Cualquier nombre de pantalla sin vista registrada en main.py cae aquí
gracias al fallback de mostrar_pantalla().
"""

from tkinter import ttk


class EnConstruccion(ttk.Frame):
    """Vista placeholder: avisa que la sección aún no está disponible."""

    def __init__(self, parent, app):
        super().__init__(parent)
        self.app = app

        # Cuadro centrado con el aviso
        panel = ttk.Frame(self, style="Panel.TFrame", padding=40)
        panel.place(relx=0.5, rely=0.5, anchor="center")

        ttk.Label(
            panel,
            text="⚙️ Pantalla en Construcción",
            style="Titulo.TLabel",
        ).pack(pady=(0, 10))

        ttk.Label(
            panel,
            text="Esta sección estará disponible en las próximas etapas.",
            style="Subtitulo.TLabel",
        ).pack()

    def actualizar(self):
        """No hay estado que refrescar en esta vista placeholder."""
        pass
