"""tests/test_app.py — Suite de pruebas de FoodShare Network (FASE 5 — EL ESCUDO).

Cobertura mínima exigida por la especificación:
  * formatear_fecha() con date, string, string inválido y None.
  * USUARIOS: las 3 cuentas existen, roles válidos, claves no vacías.
  * DONACIONES: 8 registros, campos obligatorios presentes, estados válidos.
  * Lógica de validación de login (éxito, clave mala, rol incorrecto).
  * Estilos ttk requeridos tras llamar configurar_estilos().

Cobertura adicional (contrato y ciclo de sesión):
  * Constantes de la paleta y fuentes contra los valores de la especificación.
  * Ciclo iniciar_sesion() / mostrar_pantalla() / cerrar_sesion() de App.
  * Contrato de vistas: heredan de ttk.Frame y exponen actualizar().

Nota técnica (especificación): los tests gráficos crean el root con
tkinter.Tk(), llaman withdraw() para no mostrar ventana visible y lo destruyen
al terminar (setUp/tearDown). Si no hay display disponible, el test se omite.
"""

import os
import sys
import unittest
from datetime import date, timedelta

# Permite que `python -m unittest discover tests` (ejecutado desde GUI_V1.2)
# resuelva los imports del proyecto aunque el directorio de inicio sea tests/.
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import tkinter as tk
from tkinter import ttk

import estilos
from datos_demo import DONACIONES, USUARIOS, formatear_fecha
from main import App
from vistas import EnConstruccion, Login
from vistas.login import TEXTO_ERROR


# ── Helpers ────────────────────────────────────────────────────────────────

class AppDoble:
    """Doble mínimo del contrato de App: iniciar_sesion() y usuario_actual.

    Replica el comportamiento del contrato: al iniciar sesión guarda el
    email y los datos del usuario registrados en USUARIOS.
    """

    def __init__(self):
        self.usuario_actual = None
        self.emails_sesion = []  # registro de llamadas para las aserciones

    def iniciar_sesion(self, email):
        self.emails_sesion.append(email)
        self.usuario_actual = {"email": email, **USUARIOS[email]}


class CasoGrafico(unittest.TestCase):
    """Base para tests tkinter: root con withdraw() y destrucción garantizada."""

    def setUp(self):
        try:
            self.root = tk.Tk()
        except tk.TclError as exc:
            self.skipTest(f"Sin display disponible: {exc}")
        self.root.withdraw()

    def tearDown(self):
        root = getattr(self, "root", None)
        if root is not None:
            root.update_idletasks()
            root.destroy()
            self.root = None


# ── formatear_fecha() ──────────────────────────────────────────────────────

class TestFormatearFecha(unittest.TestCase):
    """Cubre formatear_fecha() con date, string, string inválido y None."""

    def test_date_devuelve_dd_mm_aaaa(self):
        self.assertEqual(formatear_fecha(date(2024, 3, 5)), "05/03/2024")

    def test_date_fin_de_anio(self):
        self.assertEqual(formatear_fecha(date(2025, 12, 31)), "31/12/2025")

    def test_string_valido(self):
        self.assertEqual(formatear_fecha("2024-03-05"), "05/03/2024")

    def test_string_valido_dia_mes_un_digito(self):
        # El formateo rellena con cero a la izquierda según el formato dd/mm.
        self.assertEqual(formatear_fecha("2024-1-2"), "02/01/2024")

    def test_string_invalido_devuelve_vacio(self):
        self.assertEqual(formatear_fecha("no-es-fecha"), "")

    def test_string_con_formato_erroneo_devuelve_vacio(self):
        self.assertEqual(formatear_fecha("05/03/2024"), "")

    def test_string_incompleto_devuelve_vacio(self):
        self.assertEqual(formatear_fecha("2024-03"), "")

    def test_none_devuelve_vacio(self):
        self.assertEqual(formatear_fecha(None), "")


# ── USUARIOS ───────────────────────────────────────────────────────────────

class TestUsuarios(unittest.TestCase):
    """Cubre USUARIOS: cuentas esperadas, roles válidos y claves no vacías."""

    CUENTAS_ESPERADAS = {
        "contacto@elbuensabor.mx": {
            "clave": "claveRestaurante2024",
            "rol": "restaurante",
            "nombre_entidad": "El Buen Sabor",
        },
        "recepcion@bancoesperanza.org": {
            "clave": "claveFundacion2024",
            "rol": "fundacion",
            "nombre_entidad": "Banco Esperanza",
        },
        "admin@foodshare.org": {
            "clave": "rootAdminODS123",
            "rol": "admin",
            "nombre_entidad": "Administración Central",
        },
    }

    def test_existen_las_tres_cuentas(self):
        self.assertEqual(set(USUARIOS), set(self.CUENTAS_ESPERADAS))

    def test_claves_exactas_del_contrato(self):
        for email, esperado in self.CUENTAS_ESPERADAS.items():
            self.assertEqual(USUARIOS[email]["clave"], esperado["clave"])

    def test_claves_no_vacias(self):
        for email, usuario in USUARIOS.items():
            clave = usuario.get("clave", "")
            self.assertIsInstance(clave, str)
            self.assertTrue(clave.strip(), f"{email} tiene clave vacía")

    def test_roles_validos(self):
        for email, usuario in USUARIOS.items():
            self.assertIn(
                usuario.get("rol"),
                {"restaurante", "fundacion", "admin"},
                f"{email} tiene rol inválido",
            )

    def test_roles_exactos_por_cuenta(self):
        for email, esperado in self.CUENTAS_ESPERADAS.items():
            self.assertEqual(USUARIOS[email]["rol"], esperado["rol"])

    def test_un_usuario_por_rol(self):
        roles = [u["rol"] for u in USUARIOS.values()]
        self.assertEqual(len(roles), len(set(roles)))

    def test_campos_obligatorios_presentes(self):
        for email, usuario in USUARIOS.items():
            for campo in ("clave", "rol", "nombre_entidad", "responsable"):
                self.assertIn(campo, usuario, f"{email} sin campo {campo}")
                self.assertTrue(
                    str(usuario[campo]).strip(),
                    f"{email} con campo {campo} vacío",
                )


# ── DONACIONES ─────────────────────────────────────────────────────────────

class TestDonaciones(unittest.TestCase):
    """Cubre DONACIONES: 8 registros, campos obligatorios y estados válidos."""

    CAMPOS_OBLIGATORIOS = (
        "id_donacion",
        "descripcion",
        "peso_kg",
        "fecha_vencimiento",
        "estado",
        "restaurante",
        "reservado_por",
    )
    ESTADOS_VALIDOS = {"Disponible", "Reservada", "Entregada", "Vencida"}

    def test_son_ocho_registros(self):
        self.assertEqual(len(DONACIONES), 8)

    def test_ids_don021_a_don028(self):
        ids = sorted(d["id_donacion"] for d in DONACIONES)
        self.assertEqual(
            ids, [f"DON0{n}" for n in range(21, 29)]
        )

    def test_ids_unicos(self):
        ids = [d["id_donacion"] for d in DONACIONES]
        self.assertEqual(len(ids), len(set(ids)))

    def test_campos_obligatorios_presentes(self):
        for d in DONACIONES:
            for campo in self.CAMPOS_OBLIGATORIOS:
                self.assertIn(campo, d, f"{d.get('id_donacion')} sin {campo}")

    def test_estados_validos(self):
        for d in DONACIONES:
            self.assertIn(
                d["estado"],
                self.ESTADOS_VALIDOS,
                f"{d['id_donacion']} con estado inválido: {d['estado']}",
            )

    def test_hay_al_menos_un_registro_por_estado(self):
        estados = {d["estado"] for d in DONACIONES}
        self.assertEqual(estados, self.ESTADOS_VALIDOS)

    def test_peso_positivo_numerico(self):
        for d in DONACIONES:
            self.assertIsInstance(d["peso_kg"], (int, float))
            self.assertGreater(d["peso_kg"], 0)

    def test_descripcion_no_vacia(self):
        for d in DONACIONES:
            self.assertTrue(d["descripcion"].strip())

    def test_fecha_vencimiento_es_date(self):
        for d in DONACIONES:
            self.assertIsInstance(d["fecha_vencimiento"], date)

    def test_fechas_relativas_incluyen_pasadas_y_futuras(self):
        hoy = date.today()
        hay_pasadas = any(d["fecha_vencimiento"] < hoy for d in DONACIONES)
        hay_futuras = any(d["fecha_vencimiento"] > hoy for d in DONACIONES)
        self.assertTrue(hay_pasadas, "No hay fechas vencidas pasadas")
        self.assertTrue(hay_futuras, "No hay fechas futuras")

    def test_restaurante_es_el_buen_sabor(self):
        for d in DONACIONES:
            self.assertEqual(d["restaurante"], "El Buen Sabor")

    def test_reservadas_y_entregadas_tienen_reservante(self):
        for d in DONACIONES:
            if d["estado"] in ("Reservada", "Entregada"):
                self.assertTrue(
                    d["reservado_por"],
                    f"{d['id_donacion']} {d['estado']} sin reservado_por",
                )


# ── Estilos: constantes y configuración ttk ────────────────────────────────

class TestEstilosConstantes(unittest.TestCase):
    """Verifica la paleta y fuentes contra los valores de la especificación."""

    def test_paleta_exacta(self):
        self.assertEqual(estilos.BG_VENTANA, "#F8FAFC")
        self.assertEqual(estilos.BG_PANEL, "#FFFFFF")
        self.assertEqual(estilos.BG_SIDEBAR, "#EDF4FF")
        self.assertEqual(estilos.BORDE, "#CBD5E1")
        self.assertEqual(estilos.PRIMARIO, "#1F6F43")
        self.assertEqual(estilos.PRIMARIO_HOVER, "#165634")
        self.assertEqual(estilos.TEXTO_PRINCIPAL, "#141C25")
        self.assertEqual(estilos.TEXTO_SECUNDARIO, "#3F4941")
        self.assertEqual(estilos.ESTADO_DISPONIBLE, "#1F6F43")
        self.assertEqual(estilos.ESTADO_RESERVADA, "#1D4ED8")
        self.assertEqual(estilos.ESTADO_ENTREGADA, "#64748B")
        self.assertEqual(estilos.ESTADO_VENCIDA, "#B91C1C")

    def test_fuentes_exactas(self):
        self.assertEqual(estilos.FUENTE_BASE, ("Segoe UI", 10))
        self.assertEqual(estilos.FUENTE_TITULO, ("Segoe UI", 14, "bold"))
        self.assertEqual(estilos.FUENTE_SUBTITULO, ("Segoe UI", 11, "bold"))
        self.assertEqual(estilos.FUENTE_MONO, ("Consolas", 10))


class TestEstilosTtk(CasoGrafico):
    """Verifica los estilos ttk del contrato tras configurar_estilos()."""

    ESTILOS_REQUERIDOS = [
        "TFrame",
        "Panel.TFrame",
        "Sidebar.TFrame",
        "TLabel",
        "Titulo.TLabel",
        "Subtitulo.TLabel",
        "Panel.TLabel",
        "Primario.TButton",
        "Secundario.TButton",
        "MenuLateral.TButton",
        "MenuLateralActivo.TButton",
        "Treeview",
        "Treeview.Heading",
    ]

    def setUp(self):
        super().setUp()
        estilos.configurar_estilos()
        self.style = ttk.Style()

    def _color(self, nombre, opcion, estado=None):
        valor = self.style.lookup(nombre, opcion, state=estado or [])
        return valor.lower()

    def test_tema_clam_activo(self):
        self.assertEqual(self.style.theme_use(), "clam")

    def test_todos_los_estilos_requeridos_existen(self):
        for nombre in self.ESTILOS_REQUERIDOS:
            self.assertTrue(
                self.style.lookup(nombre, "background"),
                f"Estilo no definido tras configurar_estilos(): {nombre}",
            )

    def test_fondos_de_frames(self):
        self.assertEqual(self._color("TFrame", "background"),
                         estilos.BG_VENTANA.lower())
        self.assertEqual(self._color("Panel.TFrame", "background"),
                         estilos.BG_PANEL.lower())
        self.assertEqual(self._color("Sidebar.TFrame", "background"),
                         estilos.BG_SIDEBAR.lower())

    def test_primario_es_verde_con_texto_blanco(self):
        self.assertEqual(self._color("Primario.TButton", "background"),
                         estilos.PRIMARIO.lower())
        self.assertEqual(self._color("Primario.TButton", "foreground"),
                         "#ffffff")

    def test_secundario_blanco_con_borde(self):
        self.assertEqual(self._color("Secundario.TButton", "background"),
                         "#ffffff")

    def test_menu_lateral_anclado_a_la_izquierda(self):
        self.assertEqual(self.style.lookup("MenuLateral.TButton", "anchor"), "w")

    def test_menu_lateral_activo_verde(self):
        self.assertEqual(self._color("MenuLateralActivo.TButton", "background"),
                         estilos.PRIMARIO.lower())
        self.assertEqual(self._color("MenuLateralActivo.TButton", "foreground"),
                         "#ffffff")

    def test_treeview_rowheight_y_seleccion(self):
        self.assertEqual(int(self.style.lookup("Treeview", "rowheight")), 30)
        self.assertEqual(
            self._color("Treeview", "background", estado=["selected"]),
            "#d1fae5",
        )


# ── Validación de login ────────────────────────────────────────────────────

class TestLogin(CasoGrafico):
    """Cubre validar_login(): éxito, clave mala, rol incorrecto y borrado."""

    def setUp(self):
        super().setUp()
        estilos.configurar_estilos()
        self.app = AppDoble()
        self.contenedor = ttk.Frame(self.root)
        self.vista = Login(self.contenedor, self.app)

    def _rellenar(self, email, clave, rol):
        self.vista.var_correo.set(email)
        self.vista.var_clave.set(clave)
        self.vista._seleccionar_rol(rol)

    def test_exito_restaurante(self):
        self._rellenar("contacto@elbuensabor.mx", "claveRestaurante2024",
                       "restaurante")
        self.vista.validar_login()
        self.assertEqual(self.app.emails_sesion,
                         ["contacto@elbuensabor.mx"])
        self.assertEqual(self.app.usuario_actual["rol"], "restaurante")
        self.assertEqual(self.vista.var_error.get(), "")
        # La clave se limpia tras el ingreso exitoso.
        self.assertEqual(self.vista.var_clave.get(), "")

    def test_exito_fundacion(self):
        self._rellenar("recepcion@bancoesperanza.org", "claveFundacion2024",
                       "fundacion")
        self.vista.validar_login()
        self.assertEqual(self.app.emails_sesion,
                         ["recepcion@bancoesperanza.org"])

    def test_exito_admin(self):
        self._rellenar("admin@foodshare.org", "rootAdminODS123", "admin")
        self.vista.validar_login()
        self.assertEqual(self.app.emails_sesion, ["admin@foodshare.org"])

    def test_clave_incorrecta_rechaza(self):
        self._rellenar("contacto@elbuensabor.mx", "claveMala", "restaurante")
        self.vista.validar_login()
        self.assertEqual(self.app.emails_sesion, [])
        self.assertEqual(self.vista.var_error.get(), TEXTO_ERROR)

    def test_rol_incorrecto_rechaza(self):
        # Credenciales de la fundación pero pestaña de restaurante activa.
        self._rellenar("recepcion@bancoesperanza.org", "claveFundacion2024",
                       "restaurante")
        self.vista.validar_login()
        self.assertEqual(self.app.emails_sesion, [])
        self.assertEqual(self.vista.var_error.get(), TEXTO_ERROR)

    def test_email_inexistente_rechaza(self):
        self._rellenar("nadie@inexistente.mx", "cualquier", "restaurante")
        self.vista.validar_login()
        self.assertEqual(self.app.emails_sesion, [])
        self.assertEqual(self.vista.var_error.get(), TEXTO_ERROR)

    def test_clave_vacia_rechaza(self):
        self._rellenar("contacto@elbuensabor.mx", "", "restaurante")
        self.vista.validar_login()
        self.assertEqual(self.app.emails_sesion, [])
        self.assertEqual(self.vista.var_error.get(), TEXTO_ERROR)

    def test_actualizar_limpia_formulario_y_resetea_rol(self):
        self._rellenar("admin@foodshare.org", "rootAdminODS123", "admin")
        self.vista.var_error.set("error previo")
        self.vista.actualizar()
        self.assertEqual(self.vista.var_correo.get(), "")
        self.assertEqual(self.vista.var_clave.get(), "")
        self.assertEqual(self.vista.var_error.get(), "")
        self.assertEqual(self.vista.rol_seleccionado, "restaurante")

    def test_autocompletar_por_rol(self):
        self.vista._autocompletar("fundacion")
        self.assertEqual(self.vista.var_correo.get(),
                         "recepcion@bancoesperanza.org")
        self.assertEqual(self.vista.var_clave.get(), "claveFundacion2024")

    def test_alternar_visibilidad_de_clave(self):
        self.assertEqual(self.vista.entry_clave.cget("show"), "*")
        self.vista._alternar_visibilidad()
        self.assertEqual(self.vista.entry_clave.cget("show"), "")
        self.vista._alternar_visibilidad()
        self.assertEqual(self.vista.entry_clave.cget("show"), "*")


# ── Ciclo de sesión de App y contrato de vistas ────────────────────────────

class TestApp(unittest.TestCase):
    """Cubre iniciar_sesion/mostrar_pantalla/cerrar_sesion contra App real."""

    def setUp(self):
        try:
            self.app = App()
        except tk.TclError as exc:
            self.skipTest(f"Sin display disponible: {exc}")
        self.app.withdraw()

    def tearDown(self):
        app = getattr(self, "app", None)
        if app is not None:
            app.update_idletasks()
            app.destroy()
            self.app = None

    def _frame_superior(self):
        """Widget apilado en último lugar (el que quedó arriba tras tkraise)."""
        return self.app.content_area.winfo_children()[-1]

    def test_iniciar_sesion_guarda_usuario_y_muestra_sidebar(self):
        self.app.iniciar_sesion("contacto@elbuensabor.mx")
        self.assertEqual(self.app.usuario_actual["email"],
                         "contacto@elbuensabor.mx")
        self.assertEqual(self.app.usuario_actual["rol"], "restaurante")
        self.assertEqual(self.app.sidebar.winfo_manager(), "grid")

    def test_menu_del_rol_restaurante_tiene_cuatro_botones(self):
        self.app.iniciar_sesion("contacto@elbuensabor.mx")
        self.assertEqual(len(self.app.botones_menu), 4)

    def test_menu_del_rol_fundacion_tiene_tres_botones(self):
        self.app.iniciar_sesion("recepcion@bancoesperanza.org")
        self.assertEqual(len(self.app.botones_menu), 3)

    def test_menu_del_rol_admin_tiene_cuatro_botones(self):
        self.app.iniciar_sesion("admin@foodshare.org")
        self.assertEqual(len(self.app.botones_menu), 4)

    def test_mostrar_pantalla_desconocida_cae_en_construccion(self):
        self.app.mostrar_pantalla("PantallaQueNoExiste")
        self.assertIs(self._frame_superior(),
                      self.app.frames["EnConstruccion"])

    def test_mostrar_pantalla_login_eleva_la_vista_login(self):
        self.app.mostrar_pantalla("Login")
        self.assertIs(self._frame_superior(), self.app.frames["Login"])

    def test_cerrar_sesion_limpia_estado_y_oculta_sidebar(self):
        self.app.iniciar_sesion("admin@foodshare.org")
        self.app.cerrar_sesion()
        self.assertIsNone(self.app.usuario_actual)
        self.assertEqual(self.app.botones_menu, {})
        self.assertEqual(self.app.sidebar.winfo_manager(), "")
        self.assertIs(self._frame_superior(), self.app.frames["Login"])

    def test_ciclo_completo_sesion(self):
        for email, rol in (
            ("contacto@elbuensabor.mx", "restaurante"),
            ("recepcion@bancoesperanza.org", "fundacion"),
            ("admin@foodshare.org", "admin"),
        ):
            self.app.iniciar_sesion(email)
            self.assertEqual(self.app.usuario_actual["rol"], rol)
            self.assertEqual(self.app.sidebar.winfo_manager(), "grid")
            self.app.cerrar_sesion()
            self.assertIsNone(self.app.usuario_actual)
            self.assertEqual(self.app.sidebar.winfo_manager(), "")


class TestContratoVistas(CasoGrafico):
    """Contrato: toda vista hereda de ttk.Frame y expone actualizar()."""

    def setUp(self):
        super().setUp()
        estilos.configurar_estilos()
        self.app = AppDoble()
        self.contenedor = ttk.Frame(self.root)

    def test_login_cumple_el_contrato(self):
        vista = Login(self.contenedor, self.app)
        self.assertIsInstance(vista, ttk.Frame)
        self.assertTrue(callable(vista.actualizar))

    def test_en_construccion_cumple_el_contrato(self):
        vista = EnConstruccion(self.contenedor, self.app)
        self.assertIsInstance(vista, ttk.Frame)
        self.assertTrue(callable(vista.actualizar))
        vista.actualizar()  # actualizar() de EnConstruccion debe ser no op.


if __name__ == "__main__":
    unittest.main()
