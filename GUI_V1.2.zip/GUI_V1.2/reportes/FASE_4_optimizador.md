# FASE 4 — EL OPTIMIZADOR ⚡

**Proyecto:** FoodShare Network (demo ODS 2)
**Alcance:** refactoring sin cambio de comportamiento ni contratos, decisión sobre
los hallazgos del Crítico, verificación de rendimiento y **diff funcional = cero**.

## Resultado general

**Refactor aplicado a 4 de los 6 archivos** (`estilos.py`, `datos_demo.py`,
`main.py`, `vistas/login.py`). `vistas/__init__.py` y `vistas/en_construccion.py`
no necesitaban cambios y se dejaron intactos.

**Diff funcional = CERO (confirmado).** La batería funcional completa produjo salida
idéntica (72 líneas comparadas con `diff`, sin diferencias) sobre el código
pre-refactor y el post-refactor.

## Cómo se verificó el diff funcional

1. **Copias temporales**: los 6 archivos se copiaron a un directorio temporal
   fuera de `GUI_V1.2` antes de tocar nada.
2. **Batería funcional** (script temporal, ejecutado con root `withdraw()` y
   destruido al final, borrado tras la verificación). Cubrió:
   - `formatear_fecha()` con `date`, string válido, string inválido, string con
     componentes numéricos fuera de rango (`"2024-13-45"` → `'45/13/2024'`,
     comportamiento actual preservado) y `None`.
   - `USUARIOS` completo (email, rol, clave, entidad, responsable) y `DONACIONES`
     (8 registros DON021–DON028, 4 estados válidos).
   - Los 9 estilos ttk del contrato + `TFrame`, `TLabel`, `Treeview`,
     `Treeview.Heading` presentes tras `configurar_estilos()`, con valores
     clave (`Primario` bg/hover, `rowheight=30`, `Heading` bg).
   - **Login con las 3 cuentas demo** (restaurante/fundación/admin): validación,
     `usuario_actual`, claves de `botones_menu`, textos y orden de los botones
     del sidebar, botón activo resaltado (`MenuLateralActivo.TButton`), navegación
     entre pantallas del menú y reset de estilos.
   - **Clave mala**, **rol malo** y **email inexistente** → mensaje de error
     exacto `"⚠️ Credenciales incorrectas o rol no coincidente."`.
   - **Cerrar sesión**: `usuario_actual=None`, `botones_menu={}`, sidebar oculto.
   - Autocompletado de las 3 cuentas demo, alternancia 👁 (`*` ⇄ `""`),
     selección de pestaña (colores activo/inactivo), `actualizar()` del login.
   - **Fallback**: `mostrar_pantalla("PantallaInexistente")` cae en
     `EnConstruccion` sin error.
3. **Resultado**: `python -m py_compile` sobre los 6 archivos sin errores;
   salida de la batería **idéntica antes y después** (`diff` vacío, exit 0).
4. Limpieza: copias temporales, script y `__pycache__` eliminados; la
   estructura contiene solo los archivos especificados.

## Hallazgos del Crítico — decisión

| # | Hallazgo | Decisión | Detalle |
|---|---|---|---|
| 1 (mejora) | Entry de contraseña sin `width`, desalineado del correo (`width=40`) | **APLICADO** | Se añadió `width=40` al Entry de contraseña en `login.py`. Es la única alteración visible intencionada, recomendada por el Crítico; no afecta a la batería funcional (solo geometría solicitada). |
| 2a (estilo) | Literal `"#FFFFFF"` repetido en `estilos.py` (×3) y `login.py` | **APLICADO** | Nueva constante interna `TEXTO_BLANCO = "#FFFFFF"` en `estilos.py` (no forma parte del contrato; las 13+4 expuestas quedan intactas). |
| 2b (estilo) | Literal `"#E2E8F0"` repetido en `estilos.py` (hover Secundario) y `login.py` (hover botones demo) | **APLICADO** | Nueva constante interna `GRIS_HOVER = "#E2E8F0"`. |
| 2c (estilo) | Fuentes de pestaña `("Segoe UI", 9[, "bold"])` inline frente a `FUENTE_BASE` | **APLICADO** | Nuevas constantes internas `FUENTE_PESTANA` / `FUENTE_PESTANA_ACTIVA`, usadas en `_pintar_pestanas`. Además `FUENTE_BASE_BOLD` reemplaza dos tuplas bold inline en `estilos.py`. |
| 3 (estilo) | `_construir` sin docstring | **APLICADO** | Docstring de una línea añadido. |
| 4 (estilo) | `padding=10` entero vs tuplas en Primario/Secundario | **DESCARTADO** | La especificación dice literalmente "padding=10" para `MenuLateral.TButton`; cambiarlo a tupla alejaría el código del texto de la especificación aunque tkinter lo trate igual. Se prioriza fidelidad literal. |

### Comentarios "# PENDIENTE" (todos resueltos por dictamen del Crítico)

| Ubicación | Decisión |
|---|---|
| `datos_demo.py` (nombres de `responsable`) | **RETIRADO** — dictamen "Confirmado, sin ambigüedad restante". |
| `datos_demo.py` (string inválido en `formatear_fecha`) | **RETIRADO** — dictamen "Confirmado"; además la FASE 5 debe probar ese caso. Se sustituyó por un comentario normal explicativo. |
| `login.py` (Checkbutton "Recordar sesión") | **RETIRADO** — dictamen "Confirmado, persistencia fuera de alcance". Se sustituyó por un comentario normal. |
| `estilos.py` (hover `#DCE9FF` del menú lateral) | **Sustituido por constante** `AZUL_HOVER_MENU` (mismo valor); la duda quedó resuelta por el Crítico y el literal ahora está documentado. |

## Refactor propio (sin hallazgo previo)

- **`main.py` — factor `_vaciar_sidebar()`**: el patrón "destruir hijos del
  sidebar + resetear `botones_menu`" estaba duplicado en `_construir_menu()` y
  `cerrar_sesion()`. Se extrajo en un método privado con docstring; ambos puntos
  lo reutilizan. Orden de operaciones idéntico al original.
- **`login.py` — `_alternar_visibilidad()`**: el if/else con dos `configure` se
  simplificó a una asignación condicional del valor `show`. Mismas transiciones.

## Revisión de rendimiento

- Sin loops innecesarios al construir el menú (se itera una vez por entrada de
  `MENUS_POR_ROL[rol]`, como antes).
- Los widgets del sidebar se recrean solo al iniciar sesión (una vez por
  sesión); las vistas se instancian una sola vez en `App.__init__` y se alternan
  con `tkraise()`, sin recreación.
- Imports: solo `tkinter`, `ttk` y módulos propios; sin dependencias externas ni
  imports pesados.
- `_vaciar_sidebar()` no añade complejidad: mismo número de pasadas sobre
  `winfo_children()` que el código original.

## Integridad de contratos (verificada)

- Constantes expuestas de `estilos.py`: 13 colores + 4 fuentes, **valores
  exactos e inalterados**; `configurar_estilos()` con tema `clam` y los 9 estilos
  ttk del contrato 6 (valores finales idénticos: la batería confirma bg/hover).
- `datos_demo.py`: `USUARIOS`, `DONACIONES` y `formatear_fecha()` sin cambios
  de comportamiento (incluido el caso `"2024-13-45"`).
- Firmas públicas intactas: `__init__(self, parent, app)`, `actualizar()`,
  `validar_login()`, `App.iniciar_sesion(email)`, `App.mostrar_pantalla(nombre)`,
  `App.cerrar_sesion()`, `App.usuario_actual`, `App.botones_menu`.
- Estructura de archivos: 6 archivos de código + especificación + 4 reportes;
  sin archivos nuevos, sin `__pycache__`, sin dependencias externas.

## Entregable a FASE 5 (El Escudo)

- Código refactorizado y verificado (diff funcional = cero, 72/72 líneas de
  salida idénticas).
- Caso `formatear_fecha("2024-13-45")` → `'45/13/2024'`: comportamiento
  heredado de fases anteriores (la especificación solo exige "" para string
  inválido no parseable; `"2024-13-45"` sí es parseable numéricamente). Se
  deja constancia para que el Escudo no lo trate como regresión si lo compara
  con la especificación.
