# FASE 1 — EL CONSTRUCTOR 🔨

**Proyecto:** FoodShare Network (demo de redistribución de alimentos, ODS 2)
**Alcance:** generación del código funcional de la estructura GUI_V1.2 según
`especificacion.txt` (contratos + especificación funcional).

## Archivos creados

| # | Archivo | Estado |
|---|---------|--------|
| 1 | `main.py` | ✅ Creado y compilado |
| 2 | `datos_demo.py` | ✅ Creado y compilado |
| 3 | `estilos.py` | ✅ Creado y compilado |
| 4 | `vistas/__init__.py` | ✅ Creado y compilado |
| 5 | `vistas/login.py` | ✅ Creado y compilado |
| 6 | `vistas/en_construccion.py` | ✅ Creado y compilado |

No se creó ningún archivo fuera de la estructura. No queda `__pycache__`
(los generados por `py_compile` y la prueba de humo fueron eliminados).
`tests/` queda reservada para la FASE 5 (El Escudo).

## Contratos implementados

1. **estilos.py** ✅ — Expone las 13 constantes de color (`BG_VENTANA`,
   `BG_PANEL`, `BG_SIDEBAR`, `BORDE`, `PRIMARIO`, `PRIMARIO_HOVER`,
   `TEXTO_PRINCIPAL`, `TEXTO_SECUNDARIO`, `ESTADO_DISPONIBLE`,
   `ESTADO_RESERVADA`, `ESTADO_ENTREGADA`, `ESTADO_VENCIDA`) y las 4 fuentes
   (`FUENTE_BASE`, `FUENTE_TITULO`, `FUENTE_SUBTITULO`, `FUENTE_MONO`),
   con los valores exactos de la especificación. `configurar_estilos()` usa el
   tema `clam` y define los 9 estilos ttk del contrato 6.
2. **datos_demo.py** ✅ — `USUARIOS` (3 cuentas con las claves exactas),
   `DONACIONES` (8 dicts DON021–DON028 con fechas relativas vía `timedelta`,
   incluidas pasadas, y estados Disponible/Reservada/Entregada/Vencida) y
   `formatear_fecha()` (date o "AAAA-MM-DD" → "dd/mm/aaaa"; "" si nulo).
3. **vistas/__init__.py** ✅ — `from .login import Login` y
   `from .en_construccion import EnConstruccion`.
4. **Herencia de vistas** ✅ — `Login` y `EnConstruccion` heredan de
   `ttk.Frame` con firma `__init__(self, parent, app)` y método público
   `actualizar()`.
5. **main.py (App)** ✅ — Expone `app.iniciar_sesion(email)`,
   `app.mostrar_pantalla(nombre)`, `app.cerrar_sesion()` y
   `app.usuario_actual`. Title "FoodShare Network", 900x600,
   resizable(False,False), sidebar oculto al inicio, fallback a
   "EnConstruccion", resaltado `MenuLateralActivo.TButton`, `tkraise()` +
   `actualizar()`. `__main__` ejecuta `App().mainloop()`.
6. **Estilos ttk** ✅ — Los 9 estilos exactos: `Panel.TFrame`,
   `Sidebar.TFrame`, `Titulo.TLabel`, `Subtitulo.TLabel`, `Panel.TLabel`,
   `Primario.TButton`, `Secundario.TButton`, `MenuLateral.TButton`,
   `MenuLateralActivo.TButton`; Treeview (rowheight=30, selección #D1FAE5)
   y Treeview.Heading (#F1F5F9, bold 9).

## Verificación realizada

- `python -m py_compile` sobre los 6 archivos: sin errores.
- Prueba de humo sin `mainloop()`: arranque de `App`, `frames` = Login +
  EnConstruccion, login con las 3 cuentas por rol (construcción del menú
  correcto por rol), navegación con fallback a EnConstruccion y resaltado del
  botón activo, cierre de sesión (estado limpio, sidebar oculto, vuelta a
  Login), `formatear_fecha()` con date/string/None, 8 donaciones con los 4
  estados válidos.

## Comentarios "# PENDIENTE" dejados para el Crítico

1. **`datos_demo.py`** — Nombres de `responsable` no definidos en la
   especificación; se usaron valores plausibles ("María Fernanda Ruiz",
   "Jorge Andrés Luna", "Comité de Coordinación ODS 2").
2. **`datos_demo.py` → formatear_fecha()** — Comportamiento ante string
   inválido no especificado; se devuelve "" (el Escudo debe probar este caso).
3. **`vistas/login.py`** — El Checkbutton "Recordar sesión en este equipo"
   solo captura su estado; la persistencia no está especificada.
4. **`vistas/login.py`** — Textos de las etiquetas de campos ("Correo",
   "Contraseña") y nombres de los botones de cuentas demo (nombres de
   entidad) no están especificados literalmente; se eligieron textos
   coherentes con la demo.
5. **`estilos.py`** — Colores exactos de hover/active de `MenuLateral.TButton`
   ("#DCE9FF") y colores de foco no especificados; se eligieron valores
   coherentes con la paleta.

## Observaciones para el Detective (FASE 2)

- Los destinos de menú `PanelRestaurante`, `PublicarDonacion`, `MisDonaciones`,
  `ExplorarDonaciones`, `MisReservas`, `PanelAdmin`, `Donaciones`, `Usuarios`
  y `Alertas` caen por diseño en `EnConstruccion` vía el fallback; no son bugs.
- En Windows la app abre ventana visible al ejecutar `python main.py`; para
  pruebas headless usar el patrón `withdraw()` indicado en la especificación.
