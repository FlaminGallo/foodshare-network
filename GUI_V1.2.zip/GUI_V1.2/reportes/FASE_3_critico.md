# FASE 3 — EL CRÍTICO 🧐

**Proyecto:** FoodShare Network (demo ODS 2)
**Alcance:** revisión estática línea por línea contra `especificacion.txt`
(contratos + especificación funcional), sin ejecutar la app. Clasificación de
hallazgos en bloqueante / mejora / estilo.

## Resultado general

**No se encontraron desviaciones bloqueantes.** Los 6 archivos de código se
compararon línea por línea contra la especificación funcional y los contratos
entre módulos: textos exactos, colores exactos (carácter a carácter), estilos
ttk del contrato, nombres, firmas y comportamientos coinciden.

**Código modificado en esta fase: ninguno.** No fue necesario aplicar ninguna
corrección. Todo lo encontrado se documenta abajo para el Optimizador (FASE 4).

## Verificación por archivo

### `main.py` (148 líneas) ✅

| Punto de la especificación | Estado |
|---|---|
| Title "FoodShare Network", 900x600, resizable(False,False) | ✅ |
| `usuario_actual=None`, `botones_menu={}` | ✅ |
| `estilos.configurar_estilos()`, fondo BG_VENTANA | ✅ |
| Grid: col 0 sidebar, col 1 (weight=1) content_area | ✅ |
| Sidebar `Sidebar.TFrame`, ancho fijo 200, `pack_propagate(False)`, OCULTO al inicio | ✅ |
| content_area apila vistas con grid `sticky="nsew"`; frames en `self.frames[nombre_clase]`; muestra "Login" | ✅ |
| `mostrar_pantalla()`: fallback a "EnConstruccion", resalta activo (`MenuLateralActivo.TButton`) y resetea los demás, `tkraise()`, `actualizar()` si existe | ✅ |
| `iniciar_sesion(email)`: guarda usuario, menú por rol, muestra sidebar | ✅ |
| Menús: restaurante → Panel/Publicar donación/Mis donaciones/Alertas; fundacion → Explorar donaciones/Mis reservas/Alertas; admin → Panel/Donaciones/Usuarios/Alertas | ✅ |
| "Cerrar sesión" (Secundario) al fondo; navegación inicial por rol (cae en EnConstruccion por fallback, por diseño) | ✅ |
| `cerrar_sesion()`: limpia estado, `grid_forget()` del sidebar, vuelve a "Login" | ✅ |
| `if __name__ == "__main__": App().mainloop()` | ✅ |

### `estilos.py` (141 líneas) ✅

- 13 constantes de color y 4 fuentes: **valores exactos** a la especificación
  (BG_VENTANA #F8FAFC, BG_PANEL #FFFFFF, BG_SIDEBAR #EDF4FF, BORDE #CBD5E1,
  PRIMARIO #1F6F43, PRIMARIO_HOVER #165634, TEXTO_PRINCIPAL #141C25,
  TEXTO_SECUNDARIO #3F4941, ESTADO_* #1F6F43/#1D4ED8/#64748B/#B91C1C;
  Segoe UI 10 / 14 bold / 11 bold y Consolas 10).
- `configurar_estilos()`: tema `clam`; los 9 estilos ttk del contrato 6
  presentes; Primario (verde/blanco/bold/hover PRIMARIO_HOVER/sin 3D);
  Secundario (blanco, borde BORDE, hover #E2E8F0); MenuLateral (plano, anchor w,
  padding 10); MenuLateralActivo (verde/blanco/bold); Treeview (rowheight 30,
  selección #D1FAE5) y Treeview.Heading (#F1F5F9, bold 9).
- Sin constantes extra ni faltantes; contrato intacto.

### `datos_demo.py` (130 líneas) ✅

- 3 cuentas con emails, claves, roles y entidades **exactos**
  (contacto@elbuensabor.mx / claveRestaurante2024 / restaurante / "El Buen Sabor";
  recepcion@bancoesperanza.org / claveFundacion2024 / fundacion / "Banco Esperanza";
  admin@foodshare.org / rootAdminODS123 / admin / "Administración Central").
- 8 donaciones DON021–DON028 con `id_donacion`, `descripcion`, `peso_kg`,
  `fecha_vencimiento` (relativa a hoy con `timedelta`, incluidas pasadas),
  estados Disponible/Reservada/Entregada/Vencida, restaurante "El Buen Sabor"
  y `reservado_por`.
- `formatear_fecha()`: date o "AAAA-MM-DD" → "dd/mm/aaaa"; "" si nulo;
  "" ante string inválido (coherente con el caso nulo).

### `vistas/__init__.py` (9 líneas) ✅

`from .login import Login` / `from .en_construccion import EnConstruccion`; exports del contrato 3.

### `vistas/en_construccion.py` (35 líneas) ✅

Centrado "⚙️ Pantalla en Construcción" (Titulo.TLabel) y "Esta sección estará
disponible en las próximas etapas."; `actualizar()` vacío. Textos exactos.

### `vistas/login.py` (201 líneas) ✅

- Cuadro centrado `.place(relx=0.5, rely=0.5, anchor="center")`.
- Título "Control de Acceso", subtítulo "Plataforma de redistribución | ODS 2
  Hambre Cero" (textos exactos).
- 3 pestañas tk.Button planas (Restaurante/Fundación/Administrador); activo =
  fondo PRIMARIO texto blanco, inactivo = fondo BORDE.
- Correo Entry `width=40`; contraseña `show="*"` con botón "👁" alternante;
  Checkbutton "Recordar sesión en este equipo".
- Etiqueta de error roja (`ESTADO_VENCIDA`, único rojo de la paleta) +
  botón "INGRESAR AL SISTEMA" (`Primario.TButton`).
- "Cuentas demo:" con 3 botones que autocompletan email/clave buscando por rol
  en `USUARIOS`.
- `validar_login()`: email existe AND clave coincide AND rol seleccionado == rol
  del usuario → `app.iniciar_sesion(email)` y limpiar contraseña; si falla →
  "⚠️ Credenciales incorrectas o rol no coincidente." (texto exacto).
- `actualizar()`: limpia formulario y resetea rol a "restaurante".

## Evaluación de los "# PENDIENTE" del Constructor

| # | Archivo | PENDIENTE | Dictamen del Crítico |
|---|---|---|---|
| 1 | `datos_demo.py` (l. 10–11) | Nombres de `responsable` no definidos en la especificación | **Confirmado.** La especificación solo exige que exista la clave; los valores ("María Fernanda Ruiz", "Jorge Andrés Luna", "Comité de Coordinación ODS 2") son coherentes y ninguna vista los usa aún. No es desviación. |
| 2 | `datos_demo.py` (l. 26–27) | Comportamiento de `formatear_fecha` ante string inválido | **Confirmado.** Coherente con el caso nulo ("" si nulo) y con la nota técnica de la FASE 5, que obliga a probar este caso. Sin ambigüedad restante. |
| 3 | `vistas/login.py` (l. 50–51) | Checkbutton "Recordar sesión" solo captura estado | **Confirmado.** La especificación solo pide el Checkbutton; persistencia fuera de alcance. |
| 4 | `vistas/login.py` | Etiquetas "Correo"/"Contraseña" y textos de botones demo | **Confirmado.** "Cuentas demo:" está literal en la especificación; "Correo"/"Contraseña" son las etiquetas de los campos y los botones usan los nombres de entidad del contrato. Coherentes. |
| 5 | `estilos.py` (l. 107) | Hover/active de `MenuLateral.TButton` = "#DCE9FF" | **Confirmado.** La especificación no define ese color; el valor elegido es coherente con BG_SIDEBAR (#EDF4FF). |

**Ningún PENDIENTE contradice la especificación; ninguno requiere corrección
bloqueante.** Se sugiere al Optimizador (FASE 4) retirar los 4 comentarios
"PENDIENTE" ya resueltos (datos_demo.py l. 10–11 y 26–27; login.py l. 50–51)
como limpieza, sin tocar el contrato.

## Revisión de malas prácticas (solicitada por la especificación)

- **Imports sin usar:** ninguno. Los imports de `login.py` (BG_PANEL, BORDE,
  ESTADO_VENCIDA, PRIMARIO, TEXTO_PRINCIPAL) se usan todos; en `main.py`,
  `tk` se usa para `tk.Frame`/`tk.Tk`.
- **Variables globales innecesarias:** ninguna. `MENUS_POR_ROL` y
  `PANTALLA_INICIO` en main.py son configuración legítima, no estado mutable.
- **Lambdas sin captura correcta:** ninguna. Todas capturan por valor por
  defecto (`lambda r=rol: ...`, `lambda p=pantalla: ...`).
- **Código duplicado:** solo literales repetidos (ver "estilo" abajo); sin
  bloques de lógica duplicados.
- **Comentarios faltantes:** el código está documentado con docstrings; el
  único punto menor se lista en "estilo".

## Hallazgos para el OPTIMIZADOR (FASE 4) — NO aplicados por regla dura

### Mejora (comportamiento visual, no desviación de texto/color de la especificación)

1. **`vistas/login.py` l. 92** — El Entry de contraseña no tiene `width`, así
   que usa el ancho por defecto (20) mientras el correo es `width=40`: los
   dos campos quedan visualmente desalineados. Alinear el ancho del campo de
   contraseña con el del correo (o definirlo en un módulo de estilos).

### Estilo (sin cambio de comportamiento externo)

2. **Literales de color duplicados** — "#FFFFFF" aparece en
   `estilos.py` (l. 64, 75, 112) y `vistas/login.py` (l. 158); "#E2E8F0" en
   `estilos.py` (l. 91, 92) y `vistas/login.py` (l. 143). No existe constante de
   contrato para ellos, así que solo se pueden centralizar en constantes
   propias (sin tocar el contrato). Mismo caso con ("Segoe UI", 9[, "bold"]) en
   `login.py` l. 158–160 frente a FUENTE_BASE de estilos.
3. **`vistas/login.py` l. 58** — El método `_construir` carece de docstring
   (los demás métodos la tienen). Añadir una de una línea.
4. **`estilos.py` l. 101** — `padding=10` entero en `MenuLateral.TButton`
   frente a tuplas `(10, 8)` en Primario/Secundario. Normalizar si se desea
   consistencia (tkinter acepta ambas; sin efecto funcional).

## Confirmaciones de integridad

- Contratos intactos: constantes, firmas, 9 estilos ttk, estructura de archivos
  y nombres sin cambios.
- No se creó ningún archivo fuera de la estructura; no hay `__pycache__`.
- `python -m py_compile` sobre los 6 archivos: **sin errores** (verificados al
  cierre de esta fase; cachés generados eliminados).

## Estado entregado a FASE 4 (El Optimizador)

- Código **idéntico** al entregado por el Detective (que a su vez era idéntico
  al del Constructor): cero cambios de producción.
- 4 comentarios "PENDIENTE" resueltos por dictamen del Crítico (limpieza
  sugerida, no obligatoria).
- 4 hallazgos documentados (1 mejora visual + 3 de estilo) para su decisión.
