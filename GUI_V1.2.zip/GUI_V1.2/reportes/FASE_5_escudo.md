# FASE 5 — EL ESCUDO 🛡️ (Testing y cobertura)

**Fecha:** ejecución sobre el código entregado por el Optimizador (FASE 4).
**Entregable:** `tests/test_app.py` (unittest, solo biblioteca estándar).

## Resultado de la ejecución

Comando: `python -m unittest discover tests -v` (desde `GUI_V1.2/`)

- **57 tests ejecutados — 57 OK (100 %).**
- Tiempo: ~8 s.
- Sin errores, sin omisiones (skip = 0) en este entorno con display.
- Todos los `__pycache__` generados durante la ejecución fueron eliminados
  posteriormente, conforme a las reglas globales.

Los 3 fallos que aparecieron en la primera ejecución fueron **defectos del
propio test** (el helper `_frame_superior()` devolvía un objeto widget donde el
test comparaba contra su nombre en cadena, al asumir erróneamente que
`winfo_children()` devuelve strings). Se corrigió el test comparando la
identidad del widget (`assertIs`). **Ningún fallo se debió al código de
producción.**

## Qué se probó (cobertura por clase)

### 1. `TestFormatearFecha` (8 tests)
- `date` → `"dd/mm/aaaa"` (incluido día/mes de un dígito con cero a la izquierda).
- String `"AAAA-MM-DD"` → `"dd/mm/aaaa"` (con ceros de relleno).
- String inválido → `""` ("no-es-fecha", formato erróneo `"05/03/2024"`,
  string incompleto `"2024-03"`).
- `None` → `""`.

### 2. `TestUsuarios` (7 tests)
- Existen exactamente las 3 cuentas del contrato (emails exactos).
- Claves exactas, no vacías y de tipo `str`.
- Roles válidos (`restaurante` / `fundacion` / `admin`), correctos por cuenta
  y sin duplicados (un usuario por rol).
- Campos `clave`, `rol`, `nombre_entidad`, `responsable` presentes y no vacíos.

### 3. `TestDonaciones` (12 tests)
- 8 registros con ids únicos `DON021`–`DON028`.
- Campos obligatorios presentes en cada registro: `id_donacion`, `descripcion`,
  `peso_kg`, `fecha_vencimiento`, `estado`, `restaurante`, `reservado_por`.
- Estados válidos: los 4 estados del contrato (`Disponible`, `Reservada`,
  `Entregada`, `Vencida`) están representados; ningún estado fuera de la lista.
- `peso_kg` numérico y > 0; `descripcion` no vacía;
  `fecha_vencimiento` es `datetime.date`.
- Hay fechas pasadas y futuras relativas a hoy (timedelta).
- Todas son de "El Buen Sabor"; las `Reservada`/`Entregada` tienen `reservado_por`.

### 4. `TestEstilosConstantes` (2 tests)
- Las 12 constantes de color con los valores exactos de la especificación.
- Las 4 tuplas de fuente (`FUENTE_BASE`, `FUENTE_TITULO`, `FUENTE_SUBTITULO`,
  `FUENTE_MONO`) exactas.

### 5. `TestEstilosTtk` (9 tests) — requiere root tkinter oculto
- Tema `clam` activo tras `configurar_estilos()`.
- Los 13 estilos quedan definidos: los 9 estilos ttk del contrato (punto 6)
  más `TFrame`, `TLabel`, `Treeview` y `Treeview.Heading`.
- Fondos de `TFrame`/`Panel.TFrame`/`Sidebar.TFrame` correctos.
- `Primario.TButton` verde con texto blanco; `Secundario.TButton` blanco.
- `MenuLateral.TButton` con `anchor="w"`; `MenuLateralActivo.TButton` verde.
- `Treeview` con `rowheight=30` y selección `#D1FAE5`.
- Nota: las comparaciones de color normalizan a minúsculas porque Tk devuelve
  los colores en minúscula.

### 6. `TestLogin` (10 tests) — doble mínimo de App, root oculto
Se usa un doble `AppDoble` que expone `iniciar_sesion()`/`usuario_actual`
según el contrato (sin violarlo), como permite la nota técnica de la fase.
- **Éxito** con las 3 cuentas (restaurante, fundación, admin): llama a
  `iniciar_sesion` con el email, limpia el error y la clave.
- **Clave mala**, **rol incorrecto** (credenciales de fundación con pestaña
  restaurante activa), **email inexistente** y **clave vacía**: muestran el
  texto de error exacto `⚠️ Credenciales incorrectas o rol no coincidente.`
  y no invocan `iniciar_sesion`.
- `actualizar()` limpia correo, clave, error y resetea el rol a "restaurante".
- `_autocompletar("fundacion")` rellena email/clave correctos.
- El botón 👁 alterna `show` entre `"*"` y `""`.

### 7. `TestApp` (8 tests) — contra `App` real, ventana withdraw()
- `iniciar_sesion` guarda `usuario_actual` (email y rol) y muestra el sidebar
  (`winfo_manager() == "grid"`).
- Menús por rol: 4 botones (restaurante, admin), 3 botones (fundacion).
- `mostrar_pantalla` con nombre desconocido cae en `EnConstruccion`
  (verificado por el orden de apilado tras `tkraise`).
- `cerrar_sesion`: `usuario_actual=None`, botones vacíos, sidebar oculto,
  vuelve a `Login`.
- Ciclo completo de sesión con las 3 cuentas.

### 8. `TestContratoVistas` (2 tests)
- `Login` y `EnConstruccion` heredan de `ttk.Frame`, firma
  `__init__(parent, app)` y exponen `actualizar()` (contrato 4).

## Qué NO se probó (y por qué)

- **Interacciones visuales reales**: colores/hover renderizados, geometría
  centrada con `.place(relx=0.5, rely=0.5)`, apariencia del tema `clam` en
  pantalla. Requieren un display real con renderizado; los tests usan el root
  oculto (`withdraw()`), que valida lógica y configuración pero no píxeles.
- **`mainloop()`**: queda validado en la verificación final del Orquestador
  (`python main.py`).
- **Navegación real por el menú lateral** (clics sobre los botones): se cubre
  indirectamente vía `mostrar_pantalla`; el callback de cada botón solo
  delega en ese método.
- **Resaltado visual del botón activo** (`MenuLateralActivo.TButton`): se
  comprueba que el estilo existe, no el cambio de estilo sobre un clic
  (verificación de estilo aplicado, no de renderizado).
- **Persistencia de "Recordar sesión"**: la especificación la declara fuera
  de alcance (se captura el estado sin persistencia).
- **Tests sobre entornos sin display**: los tests gráficos se auto-omiten con
  `skipTest` si `tk.Tk()` lanza `TclError` (p. ej. CI Linux sin X). En este
  entorno Windows no ocurrió ninguna omisión.

## Fallos devueltos al Detective

**Ninguno.** Todo fallo encontrado durante la fase fue de planteamiento del
propio test (helper de apilado de widgets) y fue corregido por el Escudo sin
tocar código de producción. No se modificó ningún contrato ni archivo de
producción; no se añadieron dependencias externas (solo `unittest` de la
biblioteca estándar).

## Cómo reejecutar

```bash
cd GUI_V1.2
python -m unittest discover tests -v
```
