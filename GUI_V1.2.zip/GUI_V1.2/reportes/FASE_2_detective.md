# FASE 2 — EL DETECTIVE 🔍

**Proyecto:** FoodShare Network (demo ODS 2)
**Alcance:** ejecución real de la app, caza de errores, pruebas manuales simuladas
y correcciones sin tocar los contratos entre módulos.

## Resultado general

**La app arranca sin errores y todas las pruebas simuladas pasan.**
No se encontraron bugs en el código del Constructor: **no fue necesario modificar
ningún archivo de producción** (`main.py`, `datos_demo.py`, `estilos.py`,
`vistas/__init__.py`, `vistas/login.py`, `vistas/en_construccion.py`).

**Bloqueantes de contrato:** ninguno.

## Validación de ejecución

1. **Arranque real (`python main.py`):** lanzada con `timeout 8` en Git Bash.
   La ventana tkinter se abrió en el escritorio, permaneció en `mainloop()`
   (terminada por timeout, exit 124) y la consola no mostró ningún traceback
   ni warning. Arranque limpio.
2. **Prueba simulada headless:** script temporal `_detective_tmp.py` (creado
   dentro de GUI_V1.2 y **borrado al terminar**) que instancia `App()`,
   fuerza ventana de 1×1 mapeada, ejercita todos los flujos y destruye el
   root al final. **67/67 comprobaciones OK** (resumen abajo).
   - Nota técnica: una primera versión del script con `root.withdraw()`
     reportó falsos negativos en `winfo_viewable()` (con la ventana
     retirada nada se mapea). Se corrigió el *script de prueba* (no la app)
     usando una ventana 1×1 mapeada; los 9 "fallos" iniciales desaparecieron,
     confirmando que eran artefactos del harness y no bugs de la aplicación.

## Pruebas ejecutadas y resultados

| # | Prueba | Resultado |
|---|--------|-----------|
| 1 | Botones de cuentas demo autocompletan email y clave (3 cuentas, búsqueda por rol en `USUARIOS`) | ✅ |
| 2 | Botón 👁 alterna `show` entre `"*"` y `""` (oculto → visible → oculto) | ✅ |
| 3 | Login con clave incorrecta → muestra exactamente `⚠️ Credenciales incorrectas o rol no coincidente.` y no inicia sesión | ✅ |
| 4 | Login con rol incorrecto (cuenta restaurante + pestaña Administrador) → mismo mensaje de error, sesión no iniciada | ✅ |
| 5 | Login correcto con `contacto@elbuensabor.mx` (rol restaurante): sesión iniciada, clave limpiada, menú de 4 botones, sidebar visible, botón activo resaltado con `MenuLateralActivo.TButton` | ✅ |
| 6 | Login correcto con `recepcion@bancoesperanza.org` (rol fundación): menú de 3 botones (`Explorar donaciones`, `Mis reservas`, `Alertas`) | ✅ |
| 7 | Login correcto con `admin@foodshare.org` (rol admin): menú de 4 botones | ✅ |
| 8 | Destinos de menú (`PanelRestaurante`, `ExplorarDonaciones`, `PanelAdmin`, …) caen en `EnConstruccion` por el fallback (por diseño, no es bug) | ✅ |
| 9 | Navegación entre pantallas del menú: el resaltado del botón activo cambia correctamente | ✅ |
| 10 | `mostrar_pantalla("NoExiste")` → fallback a `EnConstruccion` | ✅ |
| 11 | Cerrar sesión (los 3 roles): `usuario_actual=None`, botones de menú eliminados, sidebar oculto (`grid_forget`), vuelve a `Login` | ✅ |
| 12 | `Login.actualizar()`: limpia correo/clave/error, desmarca "recordar" y resetea el rol activo a "restaurante" | ✅ |
| 13 | `formatear_fecha()`: `date(2024,3,5)`→`05/03/2024`, string válido, `None`→`""`, string inválido→`""` | ✅ |
| 14 | `DONACIONES`: 8 registros, estados exactamente {Disponible, Reservada, Entregada, Vencida} | ✅ |
| 15 | Los 9 estilos ttk del contrato 6 existen tras `configurar_estilos()` | ✅ |

## Bugs encontrados y cómo se resolvieron

**Ninguno.** Revisión estática adicional (imports, nombres de archivo, estilos
referenciados, firmas `__init__(self, parent, app)`, lambdas con captura por
valor por defecto, empaquetado de widgets) sin hallazgos:

- Los imports (`estilos`, `datos_demo`, `vistas`) resuelven correctamente;
  nombres de archivo en minúsculas conformes.
- Todos los estilos usados en vistas y `main.py` están definidos en
  `configurar_estilos()`; ninguna referencia a estilo inexistente.
- Las lambdas de `command` capturan la variable de bucle correctamente
  (`lambda r=rol: ...`, `lambda p=pantalla: ...`).
- No hay `AttributeError` potencial: `botones_menu` se vacía antes de
  rellenarse en `_construir_menu()`; `mostrar_pantalla` itera sobre un dict
  que siempre existe; `Login.entry_clave` se crea antes de cualquier uso.

## Bloqueantes de contrato

Ninguno. Ninguna corrección requirió tocar constantes, firmas, estilos ttk ni
la estructura de archivos.

## Estado entregado a FASE 3 (El Crítico)

- Código intacto (sin cambios respecto a FASE 1, por ausencia de bugs).
- Sin archivos temporales (script de prueba eliminado) y sin `__pycache__`.
- Comportamiento verificado en ejecución real y en harness headless.
