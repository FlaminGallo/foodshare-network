"""datos_demo.py — Datos de demostración de FoodShare Network (ODS 2).

CONTRATO (no modificable):
    USUARIOS (dict email → {clave, rol, nombre_entidad, responsable}),
    DONACIONES (lista de dicts) y formatear_fecha(fecha).
"""

from datetime import date, timedelta


def formatear_fecha(fecha):
    """Convierte datetime.date o 'AAAA-MM-DD' a 'dd/mm/aaaa'.

    Devuelve cadena vacía si la fecha es nula o el string no es válido.
    """
    if fecha is None:
        return ""
    if isinstance(fecha, str):
        try:
            anio, mes, dia = fecha.split("-")
            return f"{int(dia):02d}/{int(mes):02d}/{int(anio)}"
        except (ValueError, AttributeError):
            # String inválido: coherente con el caso nulo, se devuelve "".
            return ""
    return fecha.strftime("%d/%m/%Y")


# ── Usuarios de demostración (claves en texto plano, solo para demo) ──
USUARIOS = {
    "contacto@elbuensabor.mx": {
        "clave": "claveRestaurante2024",
        "rol": "restaurante",
        "nombre_entidad": "El Buen Sabor",
        "responsable": "María Fernanda Ruiz",
    },
    "recepcion@bancoesperanza.org": {
        "clave": "claveFundacion2024",
        "rol": "fundacion",
        "nombre_entidad": "Banco Esperanza",
        "responsable": "Jorge Andrés Luna",
    },
    "admin@foodshare.org": {
        "clave": "rootAdminODS123",
        "rol": "admin",
        "nombre_entidad": "Administración Central",
        "responsable": "Comité de Coordinación ODS 2",
    },
}

# ── Donaciones de demostración (fechas relativas a hoy con timedelta) ──
_hoy = date.today()

DONACIONES = [
    {
        "id_donacion": "DON021",
        "descripcion": "Pan dulce y bollería (3 cajas)",
        "peso_kg": 12.5,
        "fecha_vencimiento": _hoy + timedelta(days=2),
        "estado": "Disponible",
        "restaurante": "El Buen Sabor",
        "reservado_por": None,
    },
    {
        "id_donacion": "DON022",
        "descripcion": "Verduras frescas variadas (8 kg)",
        "peso_kg": 8.0,
        "fecha_vencimiento": _hoy + timedelta(days=1),
        "estado": "Disponible",
        "restaurante": "El Buen Sabor",
        "reservado_por": None,
    },
    {
        "id_donacion": "DON023",
        "descripcion": "Arroz y pasta (caja sellada)",
        "peso_kg": 15.0,
        "fecha_vencimiento": _hoy + timedelta(days=90),
        "estado": "Disponible",
        "restaurante": "El Buen Sabor",
        "reservado_por": None,
    },
    {
        "id_donacion": "DON024",
        "descripcion": "Fruta de temporada (caja mixta)",
        "peso_kg": 10.2,
        "fecha_vencimiento": _hoy + timedelta(days=3),
        "estado": "Reservada",
        "restaurante": "El Buen Sabor",
        "reservado_por": "Banco Esperanza",
    },
    {
        "id_donacion": "DON025",
        "descripcion": "Lácteos pasteurizados (12 piezas)",
        "peso_kg": 6.0,
        "fecha_vencimiento": _hoy + timedelta(days=5),
        "estado": "Reservada",
        "restaurante": "El Buen Sabor",
        "reservado_por": "Banco Esperanza",
    },
    {
        "id_donacion": "DON026",
        "descripcion": "Sopa de verduras preparada (10 L)",
        "peso_kg": 10.0,
        "fecha_vencimiento": _hoy - timedelta(days=1),
        "estado": "Entregada",
        "restaurante": "El Buen Sabor",
        "reservado_por": "Banco Esperanza",
    },
    {
        "id_donacion": "DON027",
        "descripcion": "Carnes frías embaladas (5 kg)",
        "peso_kg": 5.0,
        "fecha_vencimiento": _hoy - timedelta(days=2),
        "estado": "Entregada",
        "restaurante": "El Buen Sabor",
        "reservado_por": "Banco Esperanza",
    },
    {
        "id_donacion": "DON028",
        "descripcion": "Ensalada preparada (4 recipientes)",
        "peso_kg": 3.5,
        "fecha_vencimiento": _hoy - timedelta(days=3),
        "estado": "Vencida",
        "restaurante": "El Buen Sabor",
        "reservado_por": None,
    },
]
